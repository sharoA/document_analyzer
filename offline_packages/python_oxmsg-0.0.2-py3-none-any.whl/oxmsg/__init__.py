__version__ = "0.0.2"

from oxmsg.message import Message

__all__ = [
    "Message",
    "__version__",
]
