UNSTRUCTURED_CLIENT_LOGGER_NAME = "unstructured-client"
