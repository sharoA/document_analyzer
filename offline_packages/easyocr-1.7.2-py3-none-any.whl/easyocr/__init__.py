from .easyocr import Reader

__version__ = '1.7.2'
